import React from 'react';
import { LayoutGrid, KanbanSquare, Calendar, Settings, Box, Plus } from 'lucide-react';
import { Project, User } from '../types';

interface SidebarProps {
  projects: Project[];
  selectedProjectId: string | null;
  onSelectProject: (id: string) => void;
  onAddProjectClick: () => void;
  activeTab: 'dashboard' | 'calendar' | 'profile';
  onTabChange: (tab: 'dashboard' | 'calendar' | 'profile') => void;
  user: User;
  onProfileClick: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  projects, 
  selectedProjectId, 
  onSelectProject, 
  onAddProjectClick,
  activeTab,
  onTabChange,
  user,
  onProfileClick
}) => {
  return (
    <aside className="w-72 hidden md:flex flex-col justify-between py-8 px-6 bg-bg-dark h-screen border-r border-[#333333] fixed left-0 top-0 z-20">
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {/* Logo */}
        <div className="flex items-center gap-4 mb-12">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center shadow-neu-flat text-primary border border-primary/20 flex-shrink-0">
             <Box size={28} />
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight text-text-main">NeuroTask</h1>
            <p className="text-xs font-medium text-text-sub">Quản lý dự án</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex flex-col gap-6">
          <NavItem 
            icon={<LayoutGrid size={20} />} 
            label="Tổng quan" 
            active={activeTab === 'dashboard'}
            onClick={() => onTabChange('dashboard')}
          />
          
          {/* Projects Section */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between px-2">
              <span className="text-xs font-bold text-text-sub uppercase tracking-wider">Dự án</span>
              <button 
                onClick={onAddProjectClick}
                className="p-1 rounded-md hover:bg-white/5 text-text-sub hover:text-primary transition-colors"
              >
                <Plus size={16} />
              </button>
            </div>
            
            <div className="flex flex-col gap-2">
              {projects.length === 0 ? (
                <div className="px-5 py-2 text-sm text-text-sub italic opacity-60">Chưa có dự án</div>
              ) : (
                projects.map(project => (
                  <NavItem 
                    key={project.id}
                    icon={<KanbanSquare size={18} />} 
                    label={project.name} 
                    active={activeTab === 'dashboard' && project.id === selectedProjectId}
                    onClick={() => {
                      onTabChange('dashboard');
                      onSelectProject(project.id);
                    }}
                  />
                ))
              )}
            </div>
          </div>

          <NavItem 
            icon={<Calendar size={20} />} 
            label="Lịch" 
            active={activeTab === 'calendar'}
            onClick={() => onTabChange('calendar')}
          />
          <NavItem icon={<Settings size={20} />} label="Cài đặt" />
        </nav>
      </div>

      {/* User Profile */}
      <div className="mt-4 pt-4 border-t border-white/5">
        <div 
          onClick={onProfileClick}
          className={`p-4 rounded-2xl flex items-center gap-3 cursor-pointer border border-white/5 hover:translate-y-[-2px] transition-all group
            ${activeTab === 'profile' ? 'shadow-neu-pressed border-primary/20' : 'shadow-neu-btn'}`}
        >
          <div className="w-10 h-10 rounded-full bg-cover bg-center shadow-neu-pressed-sm border border-white/10 group-hover:border-primary/50 transition-colors" 
              style={{ backgroundImage: `url('${user.avatarUrl || "https://picsum.photos/200"}')` }}>
          </div>
          <div className="flex flex-col overflow-hidden">
            <span className={`text-sm font-bold truncate transition-colors ${activeTab === 'profile' ? 'text-primary' : 'text-text-main group-hover:text-primary'}`}>
                {user.name}
            </span>
            <span className="text-xs text-text-sub truncate">{user.role}</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, active, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-5 py-3.5 rounded-xl text-sm font-bold transition-all duration-200 text-left
      ${active 
        ? 'text-primary shadow-neu-pressed border border-primary/20' 
        : 'text-text-sub hover:text-primary shadow-neu-btn border border-white/5 hover:translate-y-[-2px]'
      }`}>
      {icon}
      <span className="truncate">{label}</span>
    </button>
  );
};

export default Sidebar;