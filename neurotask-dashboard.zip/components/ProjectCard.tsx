import React, { useState } from 'react';
import { Edit2, Filter, ArrowUpDown } from 'lucide-react';
import TaskList from './TaskList';
import { Task, Project } from '../types';
import EditProjectModal from './EditProjectModal';

interface ProjectCardProps {
  project: Project | null;
  tasks: Task[];
  loading: boolean;
  onEditTask?: (task: Task) => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, tasks, loading, onEditTask }) => {
  const [isEditProjectOpen, setIsEditProjectOpen] = useState(false);

  // If strict requirement is null, we can return null, but a placeholder is better UX.
  if (!project) {
    return (
      <div className="p-8 rounded-3xl shadow-neu-flat border border-white/5 bg-bg-card flex flex-col items-center justify-center min-h-[400px] text-text-sub animate-fade-in">
        <p className="text-lg font-medium">Vui lòng chọn một dự án để xem chi tiết.</p>
      </div>
    );
  }

  // Calculate Progress
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const progress = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

  return (
    <div className="p-8 rounded-3xl shadow-neu-flat border border-white/5 bg-bg-card relative animate-fade-in">
      {/* Card Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-text-main mb-1">{project.name}</h2>
          <p className="text-text-sub text-sm">
             Cập nhật lần cuối: {project.createdAt?.seconds ? new Date(project.createdAt.seconds * 1000).toLocaleDateString('vi-VN') : 'Vừa xong'}
          </p>
        </div>
        <button 
          onClick={() => setIsEditProjectOpen(true)}
          className="px-4 py-2 text-sm font-bold text-primary flex items-center gap-2 rounded-xl shadow-neu-btn border border-primary/20 hover:text-white hover:bg-primary/10 transition-all active:shadow-neu-pressed"
        >
          <Edit2 size={16} />
          Chỉnh sửa
        </button>
      </div>

      {/* Progress Bar */}
      <div className="mb-10">
        <div className="flex justify-between mb-2">
          <span className="text-sm font-bold text-text-main">Tiến độ dự án</span>
          <span className="text-sm font-bold text-primary">{progress}%</span>
        </div>
        <div className="h-3 w-full rounded-full shadow-neu-pressed bg-bg-dark relative overflow-hidden">
          <div 
            className="absolute top-0 left-0 h-full bg-primary rounded-full shadow-[0_0_10px_#00E0FF] transition-all duration-700 ease-out" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      {/* Task Section Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-text-main">Danh sách công việc</h3>
        <div className="flex gap-3">
          <button className="w-10 h-10 flex items-center justify-center rounded-xl text-text-sub hover:text-primary shadow-neu-btn border border-white/5 active:shadow-neu-pressed transition-all">
            <Filter size={18} />
          </button>
          <button className="w-10 h-10 flex items-center justify-center rounded-xl text-text-sub hover:text-primary shadow-neu-btn border border-white/5 active:shadow-neu-pressed transition-all">
            <ArrowUpDown size={18} />
          </button>
        </div>
      </div>

      {/* Task List Component */}
      <TaskList tasks={tasks} loading={loading} onEditTask={onEditTask} />

      {/* Edit Project Modal */}
      <EditProjectModal 
        isOpen={isEditProjectOpen}
        onClose={() => setIsEditProjectOpen(false)}
        project={project}
      />
    </div>
  );
};

export default ProjectCard;