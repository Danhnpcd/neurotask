import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { Task, Project } from '../types';
import TaskItem from './TaskItem';

interface CalendarViewProps {
  tasks: Task[];
  projects: Project[];
  onEditTask?: (task: Task) => void;
}

const PROJECT_COLORS = [
  'text-primary',      // Cyan
  'text-purple-400',   // Purple
  'text-orange-400',   // Orange
  'text-green-400',    // Green
  'text-pink-400',     // Pink
  'text-yellow-400',   // Yellow
  'text-blue-400',     // Blue
  'text-red-400',      // Red
];

const CalendarView: React.FC<CalendarViewProps> = ({ tasks, projects, onEditTask }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-11

  // Determine days in month and start offset
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0(Sun) - 6(Sat)
  
  // Adjust for Monday start: Mon(1)->0, ..., Sun(0)->6
  const startOffset = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;

  const handlePrevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const handleNextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  // Helper to format YYYY-MM-DD for comparison
  const formatDateKey = (y: number, m: number, d: number) => {
    return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  };

  const selectedDateKey = formatDateKey(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate());

  // Filter tasks for the selected date
  const tasksForSelectedDate = tasks.filter(task => {
    if (!task.dueDate) return false;
    return task.dueDate.startsWith(selectedDateKey);
  });

  // Helpers for Project Color and Name
  const getProjectColor = (projectId: string) => {
    const index = projects.findIndex(p => p.id === projectId);
    if (index === -1) return 'text-text-sub';
    return PROJECT_COLORS[index % PROJECT_COLORS.length];
  };

  const getProjectName = (projectId: string) => {
    return projects.find(p => p.id === projectId)?.name || 'Unknown Project';
  };

  // Check if a specific day has tasks and return their project IDs
  const getTaskDots = (day: number) => {
    const key = formatDateKey(year, month, day);
    const dayTasks = tasks.filter(t => t.dueDate && t.dueDate.startsWith(key) && t.status !== 'completed');
    // Get unique project IDs for this day
    return Array.from(new Set(dayTasks.map(t => t.projectId)));
  };

  const daysArray = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const blanksArray = Array.from({ length: startOffset }, (_, i) => i);

  const weekDays = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];

  return (
    <div className="flex flex-col gap-8 animate-fade-in">
      {/* Calendar Grid Card */}
      <div className="p-6 md:p-8 rounded-3xl shadow-neu-flat border border-white/5 bg-bg-card">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-text-main flex items-center gap-3">
             <CalendarIcon className="text-primary" />
             <span className="capitalize">Tháng {month + 1}, {year}</span>
          </h2>
          <div className="flex gap-4">
             <button 
                onClick={handlePrevMonth} 
                className="w-10 h-10 flex items-center justify-center rounded-xl text-text-sub hover:text-primary shadow-neu-btn border border-white/5 active:shadow-neu-pressed transition-all"
             >
                <ChevronLeft size={24} />
             </button>
             <button 
                onClick={handleNextMonth} 
                className="w-10 h-10 flex items-center justify-center rounded-xl text-text-sub hover:text-primary shadow-neu-btn border border-white/5 active:shadow-neu-pressed transition-all"
             >
                <ChevronRight size={24} />
             </button>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-7 gap-2 md:gap-3 mb-4">
          {weekDays.map(d => (
            <div key={d} className="text-center text-text-sub font-bold text-sm py-3 uppercase tracking-wider">{d}</div>
          ))}
          
          {blanksArray.map(i => (
            <div key={`blank-${i}`} className="aspect-square"></div>
          ))}

          {daysArray.map(day => {
            const isSelected = 
              selectedDate.getDate() === day && 
              selectedDate.getMonth() === month && 
              selectedDate.getFullYear() === year;
            
            const isToday = 
              new Date().getDate() === day && 
              new Date().getMonth() === month && 
              new Date().getFullYear() === year;

            const dotProjectIds = getTaskDots(day);

            return (
              <button
                key={day}
                onClick={() => setSelectedDate(new Date(year, month, day))}
                className={`aspect-square rounded-2xl flex flex-col items-center justify-center relative transition-all duration-200 group
                  ${isSelected 
                    ? 'bg-bg-dark shadow-neu-pressed border border-primary/20 text-primary' 
                    : 'bg-bg-card shadow-neu-btn border border-white/5 text-text-main hover:-translate-y-1 hover:border-white/10'
                  }
                  ${isToday && !isSelected ? 'border-primary/50 text-primary' : ''}
                `}
              >
                <span className={`text-sm md:text-base font-bold ${isSelected ? 'scale-110' : ''}`}>{day}</span>
                {/* Colored Dots */}
                <div className="absolute bottom-2 flex gap-1 justify-center">
                    {dotProjectIds.slice(0, 3).map(pid => (
                        <span 
                          key={pid} 
                          className={`w-1.5 h-1.5 rounded-full ${getProjectColor(pid)} bg-current shadow-[0_0_5px_currentColor]`}
                        ></span>
                    ))}
                    {dotProjectIds.length > 3 && (
                       <span className="w-1.5 h-1.5 rounded-full bg-text-sub opacity-50"></span>
                    )}
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Selected Date Tasks Details */}
      <div className="flex flex-col gap-4 animate-fade-in">
         <div className="flex items-center gap-3 mb-2">
            <h3 className="text-lg font-bold text-text-main">
                Danh sách công việc - {selectedDate.getDate()}/{selectedDate.getMonth() + 1}/{selectedDate.getFullYear()}
            </h3>
            <div className="h-[1px] flex-1 bg-white/5"></div>
         </div>
         
         {tasksForSelectedDate.length > 0 ? (
           tasksForSelectedDate.map(task => (
             <div key={task.id} className="flex flex-col gap-1">
                <span className={`text-xs font-bold uppercase tracking-wide ml-1 ${getProjectColor(task.projectId)}`}>
                  [{getProjectName(task.projectId)}]
                </span>
                <TaskItem task={task} onEdit={onEditTask} />
             </div>
           ))
         ) : (
           <div className="p-8 rounded-2xl border border-dashed border-white/10 bg-white/5 flex flex-col items-center justify-center text-text-sub opacity-70">
              <p>Không có công việc nào trong ngày này.</p>
           </div>
         )}
      </div>
    </div>
  );
};

export default CalendarView;