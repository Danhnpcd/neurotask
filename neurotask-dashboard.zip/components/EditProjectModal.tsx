import React, { useState, useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { Project } from '../types';
import { updateProject } from '../services/projectService';

interface EditProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
}

const EditProjectModal: React.FC<EditProjectModalProps> = ({ isOpen, onClose, project }) => {
  const [name, setName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setName(project.name);
      // Small delay to ensure render is complete before focus
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen, project]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      setIsSubmitting(true);
      try {
        await updateProject(project.id, name);
        onClose();
      } catch (error) {
        console.error("Failed to update project", error);
        alert("Có lỗi xảy ra khi cập nhật dự án.");
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-bg-card rounded-3xl p-8 shadow-neu-flat border border-white/10 relative m-4">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-text-sub hover:text-primary transition-colors"
        >
          <X size={24} />
        </button>

        <h2 className="text-2xl font-bold text-text-main mb-6">Chỉnh sửa dự án</h2>
        
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <label className="text-sm font-bold text-text-sub">Tên dự án</label>
            <input 
              ref={inputRef}
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="px-4 py-3 rounded-xl bg-bg-dark shadow-neu-pressed border border-white/5 text-text-main focus:outline-none focus:border-primary/50 transition-colors placeholder-text-sub/30"
              required
              disabled={isSubmitting}
            />
          </div>

          <div className="flex gap-4 mt-2">
            <button 
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-xl font-bold text-text-sub bg-bg-card shadow-neu-btn border border-white/5 hover:text-text-main active:shadow-neu-pressed transition-all disabled:opacity-50"
            >
              Hủy
            </button>
            <button 
              type="submit" 
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-xl font-bold text-bg-dark bg-primary shadow-[0_0_15px_rgba(0,224,255,0.4)] hover:shadow-[0_0_25px_rgba(0,224,255,0.6)] hover:-translate-y-1 transition-all disabled:opacity-50"
            >
              {isSubmitting ? 'Đang lưu...' : 'Lưu thay đổi'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProjectModal;