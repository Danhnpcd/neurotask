import React, { useState, useEffect } from 'react';
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  MapPin, 
  Briefcase, 
  Edit2, 
  Save, 
  X, 
  LogOut, 
  Award,
  Camera
} from 'lucide-react';
import { User } from '../types';

interface ProfilePageProps {
  user: User;
  onUpdate: (user: User) => void;
  onLogout: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user, onUpdate, onLogout }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<User>(user);
  const [skillsString, setSkillsString] = useState('');

  useEffect(() => {
    setFormData(user);
    setSkillsString(user.skills.join(', '));
  }, [user]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSkillsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSkillsString(e.target.value);
  };

  const handleSave = () => {
    const updatedSkills = skillsString.split(',').map(s => s.trim()).filter(s => s !== '');
    const updatedUser = { ...formData, skills: updatedSkills };
    onUpdate(updatedUser);
    setIsEditing(false);
    alert("Cập nhật hồ sơ thành công!");
  };

  const handleCancel = () => {
    setFormData(user);
    setSkillsString(user.skills.join(', '));
    setIsEditing(false);
  };

  return (
    <div className="flex flex-col gap-8 animate-fade-in max-w-5xl mx-auto">
      {/* Header Card */}
      <div className="p-8 rounded-3xl shadow-neu-flat border border-white/5 bg-bg-card relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-primary/20 to-transparent opacity-30"></div>
        
        <div className="flex flex-col md:flex-row items-center md:items-end gap-6 relative z-10 mt-4">
          {/* Avatar */}
          <div className="relative">
            <div className="w-32 h-32 rounded-full p-1 bg-bg-dark shadow-neu-pressed border border-white/5 flex items-center justify-center overflow-hidden">
                {formData.avatarUrl ? (
                   <div 
                     className="w-full h-full rounded-full bg-cover bg-center"
                     style={{ backgroundImage: `url('${formData.avatarUrl}')` }}
                   ></div>
                ) : (
                   <UserIcon size={48} className="text-text-sub" />
                )}
            </div>
            {isEditing && (
                <div className="absolute bottom-0 right-0 bg-primary text-bg-dark p-2 rounded-full cursor-pointer shadow-lg hover:scale-110 transition-transform">
                    <Camera size={16} />
                </div>
            )}
          </div>

          {/* Name & Role */}
          <div className="flex-1 text-center md:text-left mb-2">
             {isEditing ? (
                 <div className="flex flex-col gap-2 w-full md:max-w-md">
                     <input 
                       name="name"
                       value={formData.name}
                       onChange={handleChange}
                       className="text-2xl font-extrabold bg-bg-dark border border-white/10 rounded-lg px-3 py-1 text-text-main focus:border-primary/50 outline-none shadow-neu-pressed-sm"
                       placeholder="Họ và tên"
                     />
                     <input 
                       name="role"
                       value={formData.role}
                       onChange={handleChange}
                       className="text-sm font-medium bg-bg-dark border border-white/10 rounded-lg px-3 py-1 text-primary focus:border-primary/50 outline-none shadow-neu-pressed-sm"
                       placeholder="Chức danh"
                     />
                 </div>
             ) : (
                <>
                    <h1 className="text-3xl font-extrabold text-text-main">{formData.name}</h1>
                    <p className="text-primary font-bold text-lg mt-1">{formData.role}</p>
                </>
             )}
          </div>

          {/* Actions */}
          <div className="flex gap-3">
             {isEditing ? (
                 <>
                    <button 
                        onClick={handleCancel}
                        className="px-6 py-2 rounded-xl font-bold text-text-sub bg-bg-card shadow-neu-btn border border-white/5 hover:text-text-main active:shadow-neu-pressed transition-all"
                    >
                        Hủy
                    </button>
                    <button 
                        onClick={handleSave}
                        className="px-6 py-2 rounded-xl font-bold text-bg-dark bg-primary shadow-[0_0_15px_rgba(0,224,255,0.4)] hover:shadow-[0_0_25px_rgba(0,224,255,0.6)] hover:-translate-y-1 transition-all flex items-center gap-2"
                    >
                        <Save size={18} /> Lưu
                    </button>
                 </>
             ) : (
                 <>
                    <button 
                        onClick={() => setIsEditing(true)}
                        className="px-6 py-3 rounded-xl font-bold text-text-main bg-bg-card shadow-neu-btn border border-white/5 hover:text-primary active:shadow-neu-pressed transition-all flex items-center gap-2"
                    >
                        <Edit2 size={18} /> Chỉnh sửa
                    </button>
                    <button 
                        onClick={onLogout}
                        className="px-4 py-3 rounded-xl font-bold text-red-400 bg-bg-card shadow-neu-btn border border-white/5 hover:bg-red-500/10 hover:border-red-500/30 active:shadow-neu-pressed transition-all"
                        title="Đăng xuất"
                    >
                        <LogOut size={18} />
                    </button>
                 </>
             )}
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Column 1: Contact & Info */}
          <div className="flex flex-col gap-8">
              <div className="p-8 rounded-3xl shadow-neu-flat border border-white/5 bg-bg-card flex flex-col gap-6">
                  <h3 className="text-lg font-bold text-text-main border-b border-white/5 pb-4 flex items-center gap-2">
                      <Briefcase size={20} className="text-primary" /> Thông tin liên hệ
                  </h3>
                  
                  <div className="flex flex-col gap-5">
                      <InfoField 
                        icon={<Mail size={18} />} 
                        label="Email" 
                        value={formData.email} 
                        name="email"
                        isEditing={isEditing} 
                        onChange={handleChange}
                      />
                      <InfoField 
                        icon={<Phone size={18} />} 
                        label="Điện thoại" 
                        value={formData.phone} 
                        name="phone"
                        isEditing={isEditing} 
                        onChange={handleChange}
                      />
                      <InfoField 
                        icon={<Briefcase size={18} />} 
                        label="Phòng ban" 
                        value={formData.department} 
                        name="department"
                        isEditing={isEditing} 
                        onChange={handleChange}
                      />
                      <InfoField 
                        icon={<MapPin size={18} />} 
                        label="Vị trí / Văn phòng" 
                        value={formData.location} 
                        name="location"
                        isEditing={isEditing} 
                        onChange={handleChange}
                      />
                       {isEditing && (
                           <div className="flex flex-col gap-2 mt-2">
                                <label className="text-xs font-bold text-text-sub uppercase">Avatar URL</label>
                                <input 
                                    name="avatarUrl"
                                    value={formData.avatarUrl}
                                    onChange={handleChange}
                                    className="w-full bg-bg-dark border border-white/10 rounded-xl px-4 py-2 text-text-main text-sm focus:border-primary/50 outline-none shadow-neu-pressed"
                                    placeholder="https://example.com/image.png"
                                />
                           </div>
                       )}
                  </div>
              </div>
          </div>

          {/* Column 2: Bio & Skills */}
          <div className="flex flex-col gap-8">
              <div className="p-8 rounded-3xl shadow-neu-flat border border-white/5 bg-bg-card flex flex-col gap-6 h-full">
                  <h3 className="text-lg font-bold text-text-main border-b border-white/5 pb-4 flex items-center gap-2">
                      <UserIcon size={20} className="text-primary" /> Giới thiệu
                  </h3>

                  <div className="flex flex-col gap-2">
                      <label className="text-sm font-bold text-text-sub">Tiểu sử (Bio)</label>
                      {isEditing ? (
                          <textarea 
                             name="bio"
                             value={formData.bio}
                             onChange={handleChange}
                             rows={4}
                             className="w-full bg-bg-dark border border-white/10 rounded-xl px-4 py-3 text-text-main focus:border-primary/50 outline-none shadow-neu-pressed resize-none"
                          />
                      ) : (
                          <p className="text-text-sub leading-relaxed">{formData.bio || "Chưa có thông tin giới thiệu."}</p>
                      )}
                  </div>

                  <div className="flex flex-col gap-3 mt-4">
                      <label className="text-sm font-bold text-text-sub flex items-center gap-2">
                          <Award size={16} /> Kỹ năng
                      </label>
                      {isEditing ? (
                          <div className="flex flex-col gap-2">
                            <input 
                                value={skillsString}
                                onChange={handleSkillsChange}
                                className="w-full bg-bg-dark border border-white/10 rounded-xl px-4 py-3 text-text-main focus:border-primary/50 outline-none shadow-neu-pressed"
                                placeholder="React, TypeScript, UI/UX (cách nhau bởi dấu phẩy)"
                            />
                            <p className="text-xs text-text-sub opacity-70">* Phân cách các kỹ năng bằng dấu phẩy</p>
                          </div>
                      ) : (
                          <div className="flex flex-wrap gap-2">
                              {formData.skills.length > 0 ? (
                                  formData.skills.map((skill, index) => (
                                      <span key={index} className="px-3 py-1 rounded-lg bg-bg-dark border border-white/5 text-sm font-medium text-primary shadow-neu-pressed-sm">
                                          {skill}
                                      </span>
                                  ))
                              ) : (
                                  <span className="text-text-sub text-sm italic">Chưa cập nhật kỹ năng.</span>
                              )}
                          </div>
                      )}
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

// Helper Sub-component for form fields
const InfoField = ({ icon, label, value, name, isEditing, onChange }: any) => {
    return (
        <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-bg-dark flex items-center justify-center text-text-sub shadow-neu-pressed-sm border border-white/5 shrink-0">
                {icon}
            </div>
            <div className="flex-1 overflow-hidden">
                <p className="text-xs font-bold text-text-sub uppercase mb-1">{label}</p>
                {isEditing ? (
                    <input 
                        name={name}
                        value={value}
                        onChange={onChange}
                        className="w-full bg-bg-dark border border-white/10 rounded-lg px-3 py-1 text-text-main text-sm focus:border-primary/50 outline-none shadow-neu-pressed-sm"
                    />
                ) : (
                    <p className="text-text-main font-medium truncate">{value || "---"}</p>
                )}
            </div>
        </div>
    )
}

export default ProfilePage;