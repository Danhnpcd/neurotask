import React, { useState } from 'react';
import { X } from 'lucide-react';
import { addTask } from '../services/taskService';
import { Priority } from '../types';

interface NewTaskModalProps {
  onClose: () => void;
  projectId: string;
}

const NewTaskModal: React.FC<NewTaskModalProps> = ({ onClose, projectId }) => {
  const [title, setTitle] = useState('');
  const [assignee, setAssignee] = useState('');
  const [priority, setPriority] = useState<Priority>('normal');
  const [dueDate, setDueDate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Kiểm tra kỹ projectId
    if (!projectId) {
      alert("Lỗi: Không xác định được dự án. Vui lòng tải lại trang.");
      onClose();
      return;
    }

    if (!title || !assignee) return;

    setIsSubmitting(true);
    try {
      await addTask({
        projectId,
        title,
        assignee,
        priority,
        status: 'pending',
        dueDate: dueDate || '', 
        createdAt: Date.now()
      });
      // Nếu thành công thì tốt
    } catch (error) {
      // Nếu lỗi thì log ra console nhưng vẫn cho đóng cửa sổ để tránh treo
      console.error("Lỗi thêm task:", error);
      alert("Có lỗi nhỏ khi thêm task, vui lòng kiểm tra lại console.");
    } finally {
      // BẮT BUỘC ĐÓNG CỬA SỔ Ở ĐÂY
      setIsSubmitting(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-bg-card rounded-3xl p-8 shadow-neu-flat border border-white/10 relative m-4">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-text-sub hover:text-primary transition-colors"
        >
          <X size={24} />
        </button>

        <h2 className="text-2xl font-bold text-text-main mb-6">Thêm công việc mới</h2>
        
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <label className="text-sm font-bold text-text-sub">Nội dung công việc</label>
            <input 
              type="text" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="px-4 py-3 rounded-xl bg-bg-dark shadow-neu-pressed border border-white/5 text-text-main focus:outline-none focus:border-primary/50 transition-colors"
              placeholder="Nhập tên công việc..."
              required
              disabled={isSubmitting}
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-bold text-text-sub">Người phụ trách</label>
            <input 
              type="text" 
              value={assignee}
              onChange={(e) => setAssignee(e.target.value)}
              className="px-4 py-3 rounded-xl bg-bg-dark shadow-neu-pressed border border-white/5 text-text-main focus:outline-none focus:border-primary/50 transition-colors"
              placeholder="VD: Lan Anh"
              required
              disabled={isSubmitting}
            />
          </div>

          <div className="flex gap-4">
            <div className="flex-1 flex flex-col gap-2">
                <label className="text-sm font-bold text-text-sub">Độ ưu tiên</label>
                <select 
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as Priority)}
                  className="px-4 py-3 rounded-xl bg-bg-dark shadow-neu-pressed border border-white/5 text-text-main focus:outline-none appearance-none"
                  disabled={isSubmitting}
                >
                  <option value="low">Thấp</option>
                  <option value="normal">Trung bình</option>
                  <option value="high">Cao</option>
                </select>
            </div>
            <div className="flex-1 flex flex-col gap-2">
                <label className="text-sm font-bold text-text-sub">Hạn chót (Ngày & Giờ)</label>
                <input 
                  type="datetime-local"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="px-4 py-3 rounded-xl bg-bg-dark shadow-neu-pressed border border-white/5 text-text-main focus:outline-none [color-scheme:dark]"
                  disabled={isSubmitting}
                />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isSubmitting}
            className="mt-4 py-4 rounded-xl font-bold text-bg-dark bg-primary shadow-[0_0_15px_rgba(0,224,255,0.4)] hover:shadow-[0_0_25px_rgba(0,224,255,0.6)] hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Đang thêm...' : 'Thêm công việc'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default NewTaskModal;