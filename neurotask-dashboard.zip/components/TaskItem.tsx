import React from 'react';
import { Trash2, Check, Clock, Edit2 } from 'lucide-react';
import { Task } from '../types';
import { toggleTaskStatus, deleteTask } from '../services/taskService';

interface TaskItemProps {
  task: Task;
  onEdit?: (task: Task) => void;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, onEdit }) => {
  const isCompleted = task.status === 'completed';

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleTaskStatus(task.id, task.status);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("Bạn có chắc muốn xóa công việc này?")) {
      deleteTask(task.id);
    }
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onEdit) onEdit(task);
  };

  // Badge Logic
  const getPriorityStyle = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'normal': return 'text-primary bg-primary/10 border-primary/20';
      case 'low': return 'text-text-sub bg-white/5 border-white/10';
      default: return 'text-text-sub bg-white/5 border-white/10';
    }
  };

  const priorityLabel = {
    high: 'Cao',
    normal: 'Trung bình',
    low: 'Thấp'
  }[task.priority] || 'Thấp';

  // Helper to format display (HH:mm, DD/MM/YYYY)
  const formatDisplayDate = (dateStr: string) => {
    if (!dateStr) return '';
    if (dateStr.includes('T')) {
        const [date, time] = dateStr.split('T');
        const [y, m, d] = date.split('-');
        return `${time}, ${d}/${m}/${y}`;
    }
    // Legacy format YYYY-MM-DD
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
  };

  return (
    <div 
      className={`group relative flex items-center p-4 rounded-2xl border transition-all duration-300
        ${isCompleted 
          ? 'bg-bg-dark shadow-neu-pressed border-white/5 opacity-60' 
          : 'bg-bg-card shadow-neu-btn border-white/5 hover:-translate-y-1 hover:border-primary/30'
        }`}
    >
      {/* Round Checkbox */}
      <div 
        onClick={handleToggle}
        className={`w-6 h-6 rounded-full flex items-center justify-center cursor-pointer transition-all mr-4 shrink-0
          ${isCompleted 
            ? 'bg-primary shadow-[0_0_10px_rgba(0,224,255,0.6)]' 
            : 'bg-bg-dark shadow-neu-pressed border border-white/10 hover:border-primary/50'
          }`}
      >
        {isCompleted && <Check size={14} className="text-bg-dark font-bold" strokeWidth={3} />}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
        <div className="flex-1 min-w-0">
          <h4 className={`text-base font-bold truncate transition-all ${isCompleted ? 'text-text-sub line-through decoration-2' : 'text-text-main'}`}>
            {task.title}
          </h4>
          <div className="flex items-center gap-3 mt-1 text-xs text-text-sub">
            <span className="truncate max-w-[100px]">{task.assignee}</span>
            <span className="w-1 h-1 rounded-full bg-text-sub/30"></span>
            <div className="flex items-center gap-1">
              <Clock size={12} />
              <span>{formatDisplayDate(task.dueDate)}</span>
            </div>
          </div>
        </div>

        {/* Badge */}
        <div className={`px-3 py-1 rounded-lg text-xs font-bold border ${getPriorityStyle(task.priority)} text-center md:w-auto w-fit`}>
          {priorityLabel}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity focus-within:opacity-100 ml-2">
        {onEdit && (
          <button 
            onClick={handleEdit}
            className="p-2 rounded-xl text-text-sub hover:text-primary hover:bg-white/5 transition-colors"
            title="Chỉnh sửa"
          >
            <Edit2 size={18} />
          </button>
        )}
        <button 
          onClick={handleDelete}
          className="p-2 rounded-xl text-text-sub hover:text-red-500 hover:bg-red-500/10 transition-colors"
          title="Xóa công việc"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  );
};

export default TaskItem;