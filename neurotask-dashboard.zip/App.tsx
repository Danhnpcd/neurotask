import React, { useState, useEffect } from 'react';
import { Plus, FolderPlus, Box } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import StatsRow from './components/StatsRow';
import ProjectCard from './components/ProjectCard';
import RightPanel from './components/RightPanel';
import NewTaskModal from './components/NewTaskModal';
import NewProjectModal from './components/NewProjectModal';
import EditTaskModal from './components/EditTaskModal';
import ProfilePage from './components/ProfilePage';
import CalendarView from './components/CalendarView'; 
import { Project, Task, User } from './types';
import { subscribeToProjects, addProject } from './services/projectService';
import { subscribeToTasks, subscribeToAllTasks } from './services/taskService';

const DEFAULT_USER: User = {
  name: "Minh Hoàng",
  role: "Senior Product Designer",
  avatarUrl: "https://picsum.photos/200",
  email: "hoang.minh@neurotask.com",
  phone: "0909 123 456",
  department: "Phòng Thiết kế & Trải nghiệm",
  location: "Hồ Chí Minh, Việt Nam",
  bio: "Tôi là một Product Designer đam mê tạo ra các trải nghiệm người dùng tối giản và hiệu quả. Có hơn 5 năm kinh nghiệm làm việc với các hệ thống Design System phức tạp.",
  skills: ["UI/UX Design", "React", "Figma", "Design Systems", "Prototyping"]
};

const getInitialUser = (): User => {
  const saved = localStorage.getItem('user_profile');
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      // Merge with default to ensure new fields exist if localstorage is old
      return { ...DEFAULT_USER, ...parsed };
    } catch (e) {
      console.error("Failed to parse user profile", e);
    }
  }
  return DEFAULT_USER;
};

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User>(getInitialUser);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null); 
  const [activeTab, setActiveTab] = useState<'dashboard' | 'calendar' | 'profile'>('dashboard'); 
  
  // Data State
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]); 
  const [allTasks, setAllTasks] = useState<Task[]>([]); 
  const [isTasksLoading, setIsTasksLoading] = useState(false);

  // 1. Subscribe to Projects
  useEffect(() => {
    const unsubscribe = subscribeToProjects((fetchedProjects) => {
      setProjects(fetchedProjects);
      
      // Smart selection logic
      setSelectedProjectId(prevId => {
        const stillExists = fetchedProjects.find(p => p.id === prevId);
        if (stillExists) {
          return prevId;
        } else if (fetchedProjects.length > 0) {
          return fetchedProjects[0].id;
        } else {
          return null;
        }
      });
    });
    return () => unsubscribe();
  }, []);

  // 2. Subscribe to Tasks (Dashboard View - Single Project)
  useEffect(() => {
    if (selectedProjectId && activeTab === 'dashboard') {
      setIsTasksLoading(true);
      const unsubscribe = subscribeToTasks(selectedProjectId, (fetchedTasks) => {
        setTasks(fetchedTasks);
        setIsTasksLoading(false);
      });
      return () => unsubscribe();
    } else {
      setTasks([]);
      setIsTasksLoading(false);
    }
  }, [selectedProjectId, activeTab]);

  // 3. Subscribe to ALL Tasks (Calendar View)
  useEffect(() => {
    if (activeTab === 'calendar') {
      const unsubscribe = subscribeToAllTasks((fetchedTasks) => {
        setAllTasks(fetchedTasks);
      });
      return () => unsubscribe();
    }
  }, [activeTab]);

  const handleCreateProject = async (name: string) => {
    try {
      await addProject(name);
      setIsProjectModalOpen(false);
    } catch (error) {
      console.error(error);
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
  };

  const handleUpdateUser = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    localStorage.setItem('user_profile', JSON.stringify(updatedUser));
  };

  const handleLogout = () => {
    if (window.confirm("Bạn có chắc muốn đăng xuất (Reset dữ liệu người dùng)?")) {
        localStorage.removeItem('user_profile');
        setCurrentUser(DEFAULT_USER);
        setActiveTab('dashboard'); // Return to dashboard
    }
  };

  const selectedProject = projects.find(p => p.id === selectedProjectId) || null;

  return (
    <div className="flex min-h-screen bg-bg-dark text-text-main font-sans overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        projects={projects}
        selectedProjectId={selectedProjectId}
        onSelectProject={setSelectedProjectId}
        onAddProjectClick={() => setIsProjectModalOpen(true)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        user={currentUser}
        onProfileClick={() => setActiveTab('profile')}
      />

      {/* Main Container */}
      <main className="flex-1 ml-0 md:ml-72 p-4 md:p-8 h-screen overflow-hidden flex flex-col relative z-10">
        
        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar pb-24">
            
            {projects.length === 0 ? (
                /* Empty State / Welcome View */
                <div className="h-full flex flex-col items-center justify-center text-center animate-fade-in">
                    <div className="w-24 h-24 rounded-3xl bg-bg-card shadow-neu-flat border border-white/5 flex items-center justify-center mb-6 text-primary">
                        <Box size={48} />
                    </div>
                    <h2 className="text-3xl font-extrabold text-text-main mb-3">Chào mừng đến với NeuroTask!</h2>
                    <p className="text-text-sub mb-8 max-w-md">
                        Không gian làm việc của bạn đang trống. Hãy bắt đầu hành trình quản lý công việc hiệu quả bằng cách tạo dự án đầu tiên.
                    </p>
                    <button 
                        onClick={() => setIsProjectModalOpen(true)}
                        className="px-8 py-4 rounded-2xl font-bold text-bg-dark bg-primary shadow-[0_0_20px_rgba(0,224,255,0.4)] hover:shadow-[0_0_30px_rgba(0,224,255,0.6)] hover:-translate-y-1 transition-all flex items-center gap-2"
                    >
                        <FolderPlus size={24} />
                        Tạo dự án ngay
                    </button>
                </div>
            ) : (
                /* Dashboard Grid */
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 max-w-[1600px] mx-auto animate-fade-in">
                    
                    {/* Center Panel - Spans 8 cols normally, 12 cols in Profile mode */}
                    <div className={`${activeTab === 'profile' ? 'xl:col-span-12' : 'xl:col-span-8'} flex flex-col gap-8`}>
                        <Header />
                        
                        {activeTab === 'dashboard' && (
                          <>
                            <StatsRow totalProjects={projects.length} tasks={tasks} />
                            <ProjectCard 
                              project={selectedProject} 
                              tasks={tasks} 
                              loading={isTasksLoading} 
                              onEditTask={handleEditTask}
                            />
                          </>
                        )}
                        
                        {activeTab === 'calendar' && (
                          <CalendarView 
                            tasks={allTasks} 
                            projects={projects} 
                            onEditTask={handleEditTask}
                          />
                        )}

                        {activeTab === 'profile' && (
                          <ProfilePage 
                            user={currentUser} 
                            onUpdate={handleUpdateUser} 
                            onLogout={handleLogout} 
                          />
                        )}
                    </div>

                    {/* Right Panel - Hidden in Profile Mode */}
                    {activeTab !== 'profile' && (
                        <div className="xl:col-span-4 flex flex-col pt-0 xl:pt-[80px]"> 
                            <RightPanel tasks={activeTab === 'calendar' ? allTasks : tasks} />
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* Floating Action Button (Task) */}
        {activeTab === 'dashboard' && selectedProjectId && projects.length > 0 && (
          <button 
              onClick={() => setIsTaskModalOpen(true)}
              className="fixed bottom-8 right-8 w-16 h-16 rounded-full bg-primary text-bg-dark flex items-center justify-center shadow-[0_0_20px_rgba(0,224,255,0.4)] border-2 border-primary hover:scale-105 hover:shadow-[0_0_30px_rgba(0,224,255,0.6)] transition-all z-50 group"
          >
              <Plus size={32} className="group-hover:rotate-90 transition-transform duration-300" />
          </button>
        )}

      </main>

      {/* Modals */}
      {isTaskModalOpen && selectedProjectId && (
        <NewTaskModal 
          onClose={() => setIsTaskModalOpen(false)} 
          projectId={selectedProjectId} 
        />
      )}

      {editingTask && (
        <EditTaskModal
          isOpen={!!editingTask}
          task={editingTask}
          onClose={() => setEditingTask(null)}
        />
      )}

      <NewProjectModal 
        isOpen={isProjectModalOpen} 
        onClose={() => setIsProjectModalOpen(false)}
        onConfirm={handleCreateProject}
      />
    </div>
  );
};

export default App;