
export type Priority = 'high' | 'normal' | 'low';
export type Status = 'pending' | 'in_progress' | 'completed';

export interface Project {
  id: string;
  name: string;
  createdAt: any;
  userId?: string;
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  assignee: string;
  priority: Priority;
  status: Status;
  dueDate: string; // Storing as string for display simplicity ("Hôm nay", "08:00 AM", etc.)
  createdAt: any; // Changed to any to handle Firestore Timestamp or number
}

export interface User {
  name: string;
  role: string;
  avatarUrl: string;
  email: string;      
  phone: string;      
  department: string; 
  location: string;   
  bio: string;        
  skills: string[];   
}
