import { 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  serverTimestamp,
  doc,
  updateDoc
} from "firebase/firestore";
import { db } from "../firebase";
import { Project } from "../types";

const PROJECTS_COLLECTION = "projects";

export const subscribeToProjects = (callback: (projects: Project[]) => void) => {
  const q = query(collection(db, PROJECTS_COLLECTION), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    const projects = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Project));
    callback(projects);
  });
};

export const addProject = async (name: string) => {
  try {
    await addDoc(collection(db, PROJECTS_COLLECTION), {
      name,
      createdAt: serverTimestamp(),
      userId: 'guest'
    });
  } catch (error) {
    console.error("Error adding project: ", error);
    throw error;
  }
};

export const updateProject = async (id: string, name: string) => {
  try {
    const projectRef = doc(db, PROJECTS_COLLECTION, id);
    await updateDoc(projectRef, { name });
  } catch (error) {
    console.error("Error updating project: ", error);
    throw error;
  }
};