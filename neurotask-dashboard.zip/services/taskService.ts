import { 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  doc, 
  updateDoc, 
  deleteDoc,
  where, 
  serverTimestamp 
} from "firebase/firestore";
import { db } from "../firebase";
import { Task } from "../types";

const TASKS_COLLECTION = "tasks";

export const subscribeToTasks = (projectId: string, callback: (tasks: Task[]) => void) => {
  if (!projectId) return () => {}; 

  const q = query(
    collection(db, TASKS_COLLECTION), 
    where("projectId", "==", projectId), 
    orderBy("createdAt", "desc")
  );

  return onSnapshot(q, (snapshot) => {
    const tasks = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Task));
    callback(tasks);
  });
};

// NEW: Subscribe to ALL tasks (Global View)
export const subscribeToAllTasks = (callback: (tasks: Task[]) => void) => {
  const q = query(
    collection(db, TASKS_COLLECTION),
    orderBy("createdAt", "desc")
  );

  return onSnapshot(q, (snapshot) => {
    const tasks = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Task));
    callback(tasks);
  });
};

export const addTask = async (task: Omit<Task, "id">) => {
  try {
    await addDoc(collection(db, TASKS_COLLECTION), {
      ...task,
      createdAt: serverTimestamp() 
    });
  } catch (error) {
    console.error("Error adding task: ", error);
    throw error;
  }
};

export const updateTask = async (id: string, data: Partial<Task>) => {
  try {
    const taskRef = doc(db, TASKS_COLLECTION, id);
    await updateDoc(taskRef, data);
  } catch (error) {
    console.error("Error updating task: ", error);
    throw error;
  }
};

export const toggleTaskStatus = async (taskId: string, currentStatus: Task['status']) => {
  const newStatus = currentStatus === 'completed' ? 'pending' : 'completed';
  const taskRef = doc(db, TASKS_COLLECTION, taskId);
  await updateDoc(taskRef, { status: newStatus });
};

export const deleteTask = async (taskId: string) => {
    const taskRef = doc(db, TASKS_COLLECTION, taskId);
    await deleteDoc(taskRef);
}