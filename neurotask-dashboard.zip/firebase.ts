import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAHSeAfcUyRmG7Con6sgDGN-gs14AuXpMk",
  authDomain: "neuro-task-6e6a5.firebaseapp.com",
  projectId: "neuro-task-6e6a5",
  storageBucket: "neuro-task-6e6a5.firebasestorage.app",
  messagingSenderId: "702952470864",
  appId: "1:702952470864:web:35e740dcab1be936cc5455"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);